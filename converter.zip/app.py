import os, shutil, subprocess, urllib.parse
import boto3

s3 = boto3.client("s3")

def handler(event, context):
    for rec in event["Records"]:
        bucket = rec["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(rec["s3"]["object"]["key"])   # uploads/ID.docx
        base = os.path.splitext(os.path.basename(key))[0]

        work = f"/tmp/{base}"
        os.makedirs(work, exist_ok=True)
        src = f"{work}/{base}.docx"
        s3.download_file(bucket, key, src)

        subprocess.run(
            ["soffice", "--headless", "--norestore", "--nologo",
             "-env:UserInstallation=file:///tmp/lo-profile",
             "--convert-to", "pdf:writer_pdf_Export",
             "--outdir", work, src],
            check=True, timeout=150,
            env={**os.environ, "HOME": "/tmp"},
        )

        s3.upload_file(f"{work}/{base}.pdf", bucket, f"converted/{base}.pdf",
                       ExtraArgs={"ContentType": "application/pdf"})
        shutil.rmtree(work, ignore_errors=True)
    return {"ok": True}